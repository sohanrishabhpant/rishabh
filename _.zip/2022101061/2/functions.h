#include <stdio.h>
#include<stdlib.h>
int *intersectionArray(int *arr1,int *arr2,int lenArr1,int lenArr2);
int len(const char*str);
int totintersectionArray(int *arr1,int *arr2,int lenArr1,int lenArr2);
int countCharOccurences(const char *str,int length,char ch);
char *findLongestCommonPrefix(char **str,int numStr,int maxLen);
int *maxMin(int *arr,int lenArr);
int dismaxmin(int *arr,int lenArr);
char *removeSubstring(char *str,int strLength,const char*substr,int substrLength);
char findFirstNonRepeatingChar(const char*str,int length);
int min1(int a,int b);
int max1(int a,int b);