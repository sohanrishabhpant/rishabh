#include<stdio.h>
#include<stdlib.h>
char *compressString(char*str,int length);
int ** transpose(int **matrix,int NumRow,int NumCol);
int *uniqueElements(int *arr,int length);
void reverseString(char *str,int length);
void swap (char *a,char *b);
int len(char *a);